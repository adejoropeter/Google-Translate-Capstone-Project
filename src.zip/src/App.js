import React, { useEffect, useRef, useState } from "react";
import { Route, Routes } from "react-router-dom";
import Navbar from "./components/navbar.component";
import Bookmark from "./pages/bookmark.pages";
import StateManagement from "./contextApi/statemanagement.contextApi";
import Home from "./pages/home.pages";
import Watch from "./pages/watch.pages";
import MiniWatch from "./components/miniWatch.component";
import axios from "axios";
import { RiContactsBookLine } from "react-icons/ri";
function App() {
  const [bookmarked, setBookMarked] = useState([]);
  const back = useRef(null);
  const [watch, setWatch] = useState([]);
  const [miniWatch, setMiniWatch] = useState([]);
  const [search, setSearch] = useState("");
  const [items, setItems] = useState([]);
  const [resultArray, setAr] = useState([]);

  // const resultArray = items.filter((item) => {
  //   return item.name.toLowerCase().includes(search.toLowerCase());
  //   // console.log('')
  // });

  const [firstName,setFirstName]=useState('peter')
  console.log(firstName)
  
  const videoStreamingData = () => {
    const options = {
      method: "GET",
      url: "https://youtube138.p.rapidapi.com/video/streaming-data/",
      params: { id: "VyHV0BRtdxo" },
      headers: {
        "X-RapidAPI-Key": "e89c441662msh5494c52548eb227p1fee68jsn19bd083abb9d",
        "X-RapidAPI-Host": "youtube138.p.rapidapi.com",
      },
    };

    axios
      .request(options)
      .then(function (response) {
        const { adaptiveFormats } = response.data;
        // console.log(adaptiveFormats)
        setItems(adaptiveFormats);
      })
      .catch(function (error) {
        console.error(error);
      });
  };
  useEffect(() => {
    videoStreamingData();
  }, []);
  return (
    <div className="bg-[#1F2021] w-[100vw] min-h-[100vh] flex flex-col  overflow-hidden">
      <StateManagement.Provider
        value={{
          items,
          bookmarked,
          setBookMarked,
          setItems,
          watch,
          setWatch,
          miniWatch,
          setMiniWatch,
          back,
          search,
          setSearch,
          resultArray,
        }}
      >
        
        <Navbar />
      <div onClick={()=>{
      }}>Hello</div>
        <Routes>
          <Route path="/" element={<Home />}></Route>
          <Route path="bookmark" element={<Bookmark />}></Route>
          <Route path="watch" element={<Watch />}></Route>
        </Routes>
        <MiniWatch />
      </StateManagement.Provider>
    </div>
  );
}
export default App;
