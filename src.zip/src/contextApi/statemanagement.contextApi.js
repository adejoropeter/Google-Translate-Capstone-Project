import React, { createContext } from 'react'
const StateManagement =createContext({})
export default StateManagement